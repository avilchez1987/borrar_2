# WebServer en Node

WebServer básico hecho en Express desplegando aplicaciones de React y Node o Handlebars

## Nota:
Esto es parte de mi curso de Node de cero a experto:
[https://fernando-herrera.com/#/curso/node-cero-experto](https://fernando-herrera.com/#/curso/node-cero-experto)
